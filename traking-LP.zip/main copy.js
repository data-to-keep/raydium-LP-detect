let a = 10;

if (a > 20) {
    console.log("=============")
}
else {
    console.log("/////////////////////");
}